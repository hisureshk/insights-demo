INSERT INTO employees (first_name, last_name, email, password, role) VALUES ('admin', 'admin', 'admin@hh.com', 'admin@123', 'ADMIN');
INSERT INTO employees (first_name, last_name, email, password, role) VALUES ('jai', 'murthy', 'jai@hh.com', 'jai@123', 'OWNER');
INSERT INTO employees (first_name, last_name, email, password, role) VALUES ('Alice', 'C', 'alice@hh.com', 'alice@123', 'CASHIER');
INSERT INTO employees (first_name, last_name, email, password, role) VALUES ('Andy', 'Mitchel', 'andy@hh.com', 'andy@123', 'CHEF');

INSERT INTO customers (first_name, last_name, email, mobile) VALUES ('Guest', '', 'guest@hh.com', '0000000000');

INSERT INTO menu_items (name, description, price) VALUES ('SPl. Mutton Biryani', 'SPl. Mutton Biryani', 400);
INSERT INTO menu_items (name, description, price) VALUES ('SPl. Chicken Biryani', 'SPl. Chicken Biryani', 400);
INSERT INTO menu_items (name, description, price) VALUES ('Mutton Biryani Family Pack', 'Mutton Biryani Family Pack', 730);
INSERT INTO menu_items (name, description, price) VALUES ('Chicken Biryani Family Pack', 'Chicken Biryani Family Pack', 630);
INSERT INTO menu_items (name, description, price) VALUES ('Mutton Biryani', 'Mutton Biryani', 180);
INSERT INTO menu_items (name, description, price) VALUES ('Chicken Biryani', 'Chicken Biryani', 180);
INSERT INTO menu_items (name, description, price) VALUES ('Fish Biryani', 'Fish Biryani', 410);
INSERT INTO menu_items (name, description, price) VALUES ('Prawns Biryani', 'Prawns Biryani', 410);
INSERT INTO menu_items (name, description, price) VALUES ('Egg Biryani', 'Egg Biryani', 140);

