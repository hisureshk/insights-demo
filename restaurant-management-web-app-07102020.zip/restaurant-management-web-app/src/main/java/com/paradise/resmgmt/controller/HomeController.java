package com.paradise.resmgmt.controller;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.paradise.resmgmt.model.Employee;

@Controller
public class HomeController extends BaseController {
	
	// display home page
	@GetMapping("/")
	public String viewHomePage(Model model) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if(!"anonymousUser".equals(auth.getPrincipal())) {			
			return viewDasboard(model);
		}
		return viewLoginPage(model);
	}
	
	// display home page
	@GetMapping("/login")
	public String viewLoginPage(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "index.html";		
	}

	
	// display home page
	@GetMapping("/dashboard")
	public String viewDasboard(Model model) {
		Employee employee = retrieveLoggedInUser();
		model.addAttribute("employee", employee);
		return "dashboard.html";		
	}


}
