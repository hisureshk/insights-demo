package com.paradise.resmgmt.util;

public class OrderItemVO {
	
	private long id;
	
	private String item;
	
	private int quantity = 1;
	
	private Double amount;
	
	private long orderId; 
	
	
	public long getId() {
		return id;
	}
	
	public void setId(long id) {
		this.id = id;
	}

	public String getItem() {
		return item;
	}
	
	public void setItem(String menuItem) {
		this.item = menuItem;
	}

	public int getQuantity() {
		return quantity;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
		
	public Double getAmount() {
		return amount;
	}
	
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	
	public long getOrderId() {
		return orderId;
	}
	
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
}

