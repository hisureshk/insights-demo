package com.paradise.resmgmt.model;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RoleItem {

    private Role id;
    private String text;
    private String slug;
	public static Object builder() {
		return null;
	}

}
