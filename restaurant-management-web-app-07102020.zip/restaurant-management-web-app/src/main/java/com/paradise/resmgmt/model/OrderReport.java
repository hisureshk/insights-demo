package com.paradise.resmgmt.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderReport {

	public String year;
	
	public String month;
	
	public long value;
}
