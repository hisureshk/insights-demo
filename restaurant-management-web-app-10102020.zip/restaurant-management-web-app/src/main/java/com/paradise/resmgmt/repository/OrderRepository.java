package com.paradise.resmgmt.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.paradise.resmgmt.model.Order;
import com.paradise.resmgmt.model.OrderReport;


@Repository
public interface OrderRepository extends JpaRepository<Order, Long>{
	
	   List<Order> findAllByOrderDateBetween(
			      Timestamp orderDateStart,
			      Timestamp orderDateEnd);

	   @Query(name = "ordrRepository.findOrderValueByMonthYear", nativeQuery = true)
	   List<OrderReport> findOrderValueByMonthYear();


}
