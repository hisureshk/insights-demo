package com.paradise.resmgmt.model;

import java.math.BigDecimal;

public class OrderReport {

	private BigDecimal orderYear;
	
	private BigDecimal orderMonth;
	
	private BigDecimal orderCount;
	
	private Double orderValue;
	
	public OrderReport() {
		
	}
	
	public OrderReport(BigDecimal year, BigDecimal month, BigDecimal count, Double value) {
		this.setOrderYear(year);
		this.orderMonth = month;
		this.orderCount = count;
		this.orderValue = value;
	}

	public BigDecimal getOrderYear() {
		return orderYear;
	}

	public void setOrderYear(BigDecimal orderYear) {
		this.orderYear = orderYear;
	}
	public BigDecimal getOrderMonth() {
		return orderMonth;
	}

	public void setOrderMonth(BigDecimal orderMonth) {
		this.orderMonth = orderMonth;
	}

	public Double getOrderValue() {
		return orderValue;
	}

	public void setOrderValue(Double orderValue) {
		this.orderValue = orderValue;
	}

	public BigDecimal getOrderCount() {
		return orderCount;
	}

	public void setOrderCount(BigDecimal orderCount) {
		this.orderCount = orderCount;
	}
	
}
