package com.paradise.resmgmt.model;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {
	
	@Id
	private long id;
	
	@Column(name = "order_amount")
	private Double orderAmount;
	
	@Column(name = "tax_amount")
	private Double taxAmount;
	
	@Column(name = "items_amount")
	private Double itemsAmount;
	
	@Column(name = "order_date")
	private Timestamp orderDate;
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "order")
	private List<OrderItem> orderItems;

	@ManyToOne
	private Customer customer;
	
	public Order() {
		id = System.currentTimeMillis();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public Double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Double getItemsAmount() {
		return itemsAmount;
	}
	public void setItemsAmount(Double itemsAmount) {
		this.itemsAmount = itemsAmount;
	}	
	public Timestamp getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}
	
	public void setOrderItems (List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}	
	
	public Customer getCustomer() {
		if(customer == null)  {
			return new Customer();
		}
		return customer;
	}
	public void setCustomer (Customer customer) {
		this.customer = customer;
	}	
}

