package com.paradise.resmgmt.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.paradise.resmgmt.model.Order;
import com.paradise.resmgmt.model.OrderItem;

public class RestaurantUtil {
	

	public static Order convertOrderVO(OrderVO orderVO) {
		Order order = new Order();
		order.setId(orderVO.getId());
		List <OrderItemVO> list = orderVO.getOrderItems();
		List<OrderItem> items = new ArrayList<OrderItem>();
		list.forEach(orderItem -> items.add(convertOrderItemVO(orderItem)));
		order.setOrderItems(items);
		System.out.println(" ORDER DATE IS " + orderVO.getOrderDate());
		order.setOrderDate(new Timestamp(orderVO.getOrderDate().getTime()));
		order.setOrderAmount(orderVO.getOrderAmount());
		order.setItemsAmount(order.getItemsAmount());
		order.setTaxAmount(orderVO.getTaxAmount());		
		return order;
	}
	
	public static OrderItem convertOrderItemVO(OrderItemVO orderItemVO) {
		OrderItem orderItem = new OrderItem();
		orderItem.setId(orderItemVO.getId());
		orderItem.setItem(orderItemVO.getItem());
		orderItem.setQuantity(orderItemVO.getQuantity());
		orderItem.setAmount(orderItemVO.getAmount());
		return orderItem;
	}	
	

}
