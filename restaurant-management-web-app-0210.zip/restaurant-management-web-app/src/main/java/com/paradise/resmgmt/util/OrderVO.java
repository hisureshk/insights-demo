package com.paradise.resmgmt.util;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class OrderVO {
	
	private long id;
	
	private Double orderAmount = new Double(0);
	
	private Double taxAmount = new Double(0);
	
	private Double itemsAmount = new Double(0);
	
	private Date orderDate = new Date(Calendar.getInstance().getTimeInMillis());
	
	private List<OrderItemVO> orderItems = new ArrayList<OrderItemVO>();
	
	private String custMobile;

	private String custName;
	
	private long custId;
	
	public OrderVO() {
		id = System.currentTimeMillis();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public Double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Double getItemsAmount() {
		return itemsAmount;
	}
	public void setItemsAmount(Double itemsAmount) {
		this.itemsAmount = itemsAmount;
	}	
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItemVO> getOrderItems() {
		return orderItems;
	}
	
	public void setOrderItems (List<OrderItemVO> orderItems) {
		this.orderItems = orderItems;
	}
	
	public long getCustId() {
		return custId;
	}
	
	public void setCustId (long custId) {
		this.custId = custId;
	}
	
	public String getCustMobile() {
		return custMobile;
	}
	
	public void setCustMobile (String custMobile) {
		this.custMobile = custMobile;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName (String custName) {
		this.custName = custName;
	}	
	
	public void addOrderItem(OrderItemVO orderItem) {
		orderItems.add(orderItem);
		itemsAmount += orderItem.getAmount();
		if(itemsAmount != 0 ) {
			taxAmount = (itemsAmount * 12.5) / 100;
		}
		orderAmount = itemsAmount + taxAmount;
	}

}

