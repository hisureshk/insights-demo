package com.hh.resmgmt.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.hh.resmgmt.model.MenuItem;

public interface MenuService {
	List<MenuItem> getAllMenus();
	void saveMenu(MenuItem menu);
	MenuItem getMenuById(long id);
	void deleteMenuById(long id);
	Page<MenuItem> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection);
}
