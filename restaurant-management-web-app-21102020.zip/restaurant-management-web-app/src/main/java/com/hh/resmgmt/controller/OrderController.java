package com.hh.resmgmt.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hh.resmgmt.model.Customer;
import com.hh.resmgmt.model.Employee;
import com.hh.resmgmt.model.Order;
import com.hh.resmgmt.service.CustomerService;
import com.hh.resmgmt.service.OrderService;
import com.hh.resmgmt.util.OrderItemVO;
import com.hh.resmgmt.util.OrderVO;
import com.hh.resmgmt.util.RestaurantUtil;

@Controller
public class OrderController extends BaseController {

	@Autowired
	private OrderService orderService;
	
	@Autowired
	private CustomerService customerService;
	
	// display list of orders
	@GetMapping("/orders")
	public String viewHomePage(Model model) {
		return findPaginated(1, "orderDate", "asc", model);		
	}
	
	@GetMapping("/orders/showNewOrderForm")
	public String showNewOrderForm(Model model, HttpSession session) {
		// create model attribute to bind form data
		OrderVO order = new OrderVO();		
		model.addAttribute("order", order);
		session.setAttribute(String.valueOf(order.getId()), order);
		return "order/new_order";
	}
	
	@RequestMapping(value="/orders/saveOrder", method=RequestMethod.POST, params="action=search")
	public String showCustomerOrderForm(@ModelAttribute("order") OrderVO order, Model model, HttpSession session) {
		// create model attribute to bind form data
		Customer customer = customerService.getCustomerByMobile(order.getCustMobile());
		//order.setCustomer(customer.);
		order.setCustId(customer.getId());
		order.setCustName(customer.getFirstName() + " "  + customer.getLastName());
		order.setCustMobile(customer.getMobile());
		order.setCustDiscount(customer.getDiscount());		
		model.addAttribute("order", order);
		session.setAttribute(String.valueOf(order.getId()), order);
		return "order/new_order";
	}

	@RequestMapping(value="/orders/{id}/addOrderItem", method=RequestMethod.GET)
	public String showOrderItemForm(@PathVariable ( value = "id") long id, Model model, HttpSession session) {
		// create model attribute to bind form data
		OrderItemVO orderItem = new OrderItemVO();		
		orderItem.setOrderId(id);
		model.addAttribute("orderItem", orderItem);
		return "order/new_orderItem";
	}
	
	@RequestMapping(value="/orders/{id}/orderItems/{itemId}/delete", method=RequestMethod.GET)
	public String deleteOrderItem(@PathVariable ( value = "id") long id, @PathVariable ( value = "itemId") long itemId, Model model, HttpSession session) {
		// create model attribute to bind form data
		OrderVO order = (OrderVO)session.getAttribute(String.valueOf(id));
		order.removeOrderItem(itemId);
		model.addAttribute("order", order);
		return "order/new_order";
	}
	
	@RequestMapping(value="/orders/saveOrder", method=RequestMethod.POST, params="action=saveItem")
	public String saveOrderItem(@ModelAttribute("orderItem") OrderItemVO orderItem, Model model, HttpSession session) {
		// create model attribute to bind form data
		OrderVO order = (OrderVO)session.getAttribute(String.valueOf(orderItem.getOrderId()));
		order.addOrderItem(orderItem);		
		model.addAttribute("order", order);
		return "order/new_order";
	}

	
	
	@RequestMapping(value="/orders/saveOrder", method=RequestMethod.POST, params="action=save")
	public String saveOrder(@ModelAttribute("order") OrderVO order, HttpSession session) {
		Employee employee = retrieveLoggedInUser();
		// save order to database
		OrderVO orderVO = (OrderVO)session.getAttribute(String.valueOf(order.getId()));
		String mobile = orderVO.getCustMobile();
		if((mobile == null) || mobile.equals("")) mobile = "0000000000";
		Customer customer = customerService.getCustomerByMobile(mobile);
		order.setOrderItems(orderVO.getOrderItems());		
		Order orderEntity = RestaurantUtil.convertOrderVO (orderVO);
		orderEntity.setCustomer(customer);
		orderEntity.setEmployee(employee);
		orderService.saveOrder(orderEntity);
		return "redirect:/orders";
	}
	
	@GetMapping("/orders/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		// get order from the service
		Order order = orderService.getOrderById(id);
		
		// set order as a model attribute to pre-populate the form
		model.addAttribute("order", order);
		return "order/update_order";
	}
	
	@GetMapping("/orders/deleteOrder/{id}")
	public String deleteOrder(@PathVariable (value = "id") long id) {
		
		// call delete order method 
		this.orderService.deleteOrderById(id);
		return "redirect:/orders";
	}
	
	
	@GetMapping("/orders/page/{pageNo}")
	public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField,
			@RequestParam("sortDir") String sortDir,
			Model model) {
		int pageSize = 5;
		
		Page<Order> page = orderService.findPaginated(pageNo, pageSize, sortField, sortDir);
		List<Order> listOrders = page.getContent();
		
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
		
		model.addAttribute("listOrders", listOrders);
		return "order/index";
	}
}
