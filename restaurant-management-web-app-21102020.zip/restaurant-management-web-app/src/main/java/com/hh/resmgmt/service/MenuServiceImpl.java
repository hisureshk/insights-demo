package com.hh.resmgmt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hh.resmgmt.model.MenuItem;
import com.hh.resmgmt.repository.MenuRepository;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	private MenuRepository menuRepository;

	@Override
	public List<MenuItem> getAllMenus() {
		return menuRepository.findAll();
	}

	@Override
	public void saveMenu(MenuItem menu) {
		this.menuRepository.save(menu);
	}

	@Override
	public MenuItem getMenuById(long id) {
		Optional<MenuItem> optional = menuRepository.findById(id);
		MenuItem menu = null;
		if (optional.isPresent()) {
			menu = optional.get();
		} else {
			throw new RuntimeException(" Menu not found for id :: " + id);
		}
		return menu;
	}

	@Override
	public void deleteMenuById(long id) {
		this.menuRepository.deleteById(id);
	}

	@Override
	public Page<MenuItem> findPaginated(int pageNo, int pageSize, String sortField, String sortDirection) {
		Sort sort = sortDirection.equalsIgnoreCase(Sort.Direction.ASC.name()) ? Sort.by(sortField).ascending() :
			Sort.by(sortField).descending();
		
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
		return this.menuRepository.findAll(pageable);
	}
}
