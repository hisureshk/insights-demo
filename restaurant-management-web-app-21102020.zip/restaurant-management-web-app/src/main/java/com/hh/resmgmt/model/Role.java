package com.hh.resmgmt.model;

public enum Role {

	ADMIN("Admin"), OWNER("Owner"), CHEF("Chef"), CASHIER("Cashier");

	String label;

	Role(String label) {
		this.label = label;
	}

	public String getLabel() {
		return this.label;
	}
}
