package com.hh.resmgmt.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.hh.resmgmt.model.Order;
import com.hh.resmgmt.model.OrderItem;

public class RestaurantUtil {
	

	public static Order convertOrderVO(OrderVO orderVO) {
		Order order = new Order();
		order.setId(orderVO.getId());
		List <OrderItemVO> list = orderVO.getOrderItems();
		List<OrderItem> items = new ArrayList<OrderItem>();
		list.forEach(orderItem -> items.add(convertOrderItemVO(orderItem, order)));
		order.setOrderItems(items);
		System.out.println(" ORDER DATE IS " + orderVO.getOrderDate());
		//order.setOrderDate(orderVO.getOrderDate());
		order.setOrderDate(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		order.setOrderAmount(orderVO.getOrderAmount());
		order.setItemsAmount(orderVO.getItemsAmount());
		order.setTaxAmount(orderVO.getTaxAmount());		
		return order;
	}
	
	public static OrderItem convertOrderItemVO(OrderItemVO orderItemVO, Order order) {
		OrderItem orderItem = new OrderItem();
		orderItem.setId(orderItemVO.getId());
		orderItem.setItem(orderItemVO.getItem());
		orderItem.setQuantity(orderItemVO.getQuantity());
		orderItem.setAmount(orderItemVO.getAmount());
		orderItem.setOrder(order);
		return orderItem;
	}	
	

}
