package com.hh.resmgmt.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class OrderVO {
	
	private long id;
	
	private Double orderAmount = new Double(0);
	
	private Double taxAmount = new Double(0);
	
	private Double itemsAmount = new Double(0);
	
	private Double totalAmount = new Double(0);
	
	private Double discount = new Double(0);
	
    private String orderDate = new Date().toString();
	
	private List<OrderItemVO> orderItems = new ArrayList<OrderItemVO>();
	
	private String custMobile;

	private String custName;
	
	private long custId;
	
	private Double custDiscount = new Double(0);
	
	public OrderVO() {
		id = System.currentTimeMillis();
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(Double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public Double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	
	public Double getItemsAmount() {
		return itemsAmount;
	}
	
	public void setItemsAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public Double getTotalAmount() {
		return totalAmount;
	}
	
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public Double getDiscount() {
		return discount;
	}
	
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItemVO> getOrderItems() {
		return orderItems;
	}
	
	public void setOrderItems (List<OrderItemVO> orderItems) {
		this.orderItems = orderItems;
	}
	
	public long getCustId() {
		return custId;
	}
	
	public void setCustId (long custId) {
		this.custId = custId;
	}
	
	public String getCustMobile() {
		return custMobile;
	}
	
	public void setCustMobile (String custMobile) {
		this.custMobile = custMobile;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName (String custName) {
		this.custName = custName;
	}
	
	
	public Double getCustDiscount() {
		return custDiscount;
	}
	
	public void setCustDiscount (Double custDiscount) {
		this.custDiscount = custDiscount;
	}
	
	public void addOrderItem(OrderItemVO orderItem) {
		if(orderItem.getId() > 0) {
			removeOrderItem (orderItem.getId());
		} else {
			orderItem.setId(orderItems.size()+1);	
		}		
		orderItems.add(orderItem);
		totalAmount += orderItem.getAmount();
		discount = (totalAmount * custDiscount)/100;
		itemsAmount = totalAmount - discount;
		if(itemsAmount != 0 ) {
			taxAmount = (itemsAmount * 12.5) / 100;
		}
		orderAmount = itemsAmount + taxAmount;
	}

	public void removeOrderItem(long itemId) {
		OrderItemVO removeItem = new OrderItemVO();
		for(OrderItemVO orderItem : orderItems) {
			if(orderItem.getId() == itemId) {
				removeItem = orderItem;
			}
		}
		totalAmount = totalAmount - removeItem.getAmount();
		discount = (totalAmount * custDiscount)/100;
		itemsAmount = totalAmount - discount;
		if(itemsAmount != 0 ) {
			taxAmount = (itemsAmount * 12.5) / 100;
		}
		orderAmount = itemsAmount + taxAmount;
		orderItems.remove(removeItem);
	}
	
	
	public OrderItemVO getOrderItem(long itemId) {
		OrderItemVO updateItem = new OrderItemVO();
		for(OrderItemVO orderItem : orderItems) {
			if(orderItem.getId() == itemId) {
				updateItem = orderItem;
			}
		}
		return updateItem;
	}

}

