package com.paradise.resmgmt.util;

public class Constants {
	
	public static enum ROLE {
	    ADMIN, OWNER, CHEF, FRONTDESK 
	};

}
