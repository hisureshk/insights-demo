package com.paradise.resmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.paradise.resmgmt.model.MenuItem;
import com.paradise.resmgmt.service.MenuService;

@Controller
public class MenuController {

	@Autowired
	private MenuService menuService;
	
	// display list of menus
	@GetMapping("/menus")
	public String viewHomePage(Model model) {
		return findPaginated(1, "name", "asc", model);		
	}
	
	@GetMapping("/menus/showNewMenuForm")
	public String showNewMenuForm(Model model) {
		// create model attribute to bind form data
		MenuItem menu = new MenuItem();
		model.addAttribute("menu", menu);
		return "menu/new_menu";
	}
	
	@PostMapping("/menus/saveMenu")
	public String saveMenu(@ModelAttribute("menu") MenuItem menu) {
		// save menu to database
		menuService.saveMenu(menu);
		return "redirect:/menus";
	}
	
	@GetMapping("/menus/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable ( value = "id") long id, Model model) {
		
		// get menu from the service
		MenuItem menu = menuService.getMenuById(id);
		
		// set menu as a model attribute to pre-populate the form
		model.addAttribute("menu", menu);
		return "menu/update_menu";
	}
	
	@GetMapping("/menus/deleteMenu/{id}")
	public String deleteMenu(@PathVariable (value = "id") long id) {
		
		// call delete menu method 
		this.menuService.deleteMenuById(id);
		return "redirect:/menus";
	}
	
	
	@GetMapping("/menus/page/{pageNo}")
	public String findPaginated(@PathVariable (value = "pageNo") int pageNo, 
			@RequestParam("sortField") String sortField,
			@RequestParam("sortDir") String sortDir,
			Model model) {
		int pageSize = 5;
		
		Page<MenuItem> page = menuService.findPaginated(pageNo, pageSize, sortField, sortDir);
		List<MenuItem> listMenus = page.getContent();
		
		model.addAttribute("currentPage", pageNo);
		model.addAttribute("totalPages", page.getTotalPages());
		model.addAttribute("totalItems", page.getTotalElements());
		
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("reverseSortDir", sortDir.equals("asc") ? "desc" : "asc");
		
		model.addAttribute("listMenus", listMenus);
		return "menu/index";
	}
}
