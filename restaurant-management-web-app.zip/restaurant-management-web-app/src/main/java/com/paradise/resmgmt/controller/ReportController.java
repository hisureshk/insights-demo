package com.paradise.resmgmt.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.paradise.resmgmt.model.Employee;

@Controller
public class ReportController {
	
	// display home page
	@GetMapping("/reports")
	public String viewHomePage(Model model) {		
		return "report/index.html";		
	}
	
	// display home page
	@GetMapping("/reports/id")
	public String viewLoginPage(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "report/index.html";				
	}
	
	// display home page
	@GetMapping("/reports/employeeId")
	public String viewDasboard(@ModelAttribute("employee") Employee employee, Model model) {
		model.addAttribute("employee", employee);
		return "dashboard.html";		
	}

}
